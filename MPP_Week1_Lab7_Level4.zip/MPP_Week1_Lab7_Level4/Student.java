package MPP_Week1_Lab7_Level4;

class Student implements IPerson {

    @Override
    public void myAbstract() {
        System.out.println("From abstract method.");
    }
}

