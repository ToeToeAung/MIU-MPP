package MPP_Week1_Lab7_Level4;

public class Main {
    public static void main(String[] args) {
        
        Student student = new Student();   
        student.myDefault();   
        IPerson.myStatic();
        student.myAbstract();
    }
}

