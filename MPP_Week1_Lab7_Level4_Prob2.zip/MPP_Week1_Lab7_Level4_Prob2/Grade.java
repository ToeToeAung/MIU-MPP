package MPP_Week1_Lab7_Level4_Prob2;


enum Grade{
	A,B,C,D,F;
}