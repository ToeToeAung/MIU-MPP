package MPP_Week1_Lab7_Level4_Prob2;

public class Main {

	public static void main(String[] args) {
		Grade grade=Grade.A;
		System.out.println(grade);

	}

}
