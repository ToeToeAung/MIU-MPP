package MPP_Week1_Lab7_Level4_Prob3;

public class Main {

	public static void main(String[] args) {
		Person p=new Person("Joseph",23);
		System.out.println("Name "+p.getName());
		System.out.println("Age "+p.getAge());
	}
}
